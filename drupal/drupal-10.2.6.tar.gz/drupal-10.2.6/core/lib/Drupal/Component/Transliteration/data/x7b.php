<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'mang', 'zhu', 'wan', 'du', 'ji', 'xiao', 'ba', 'suan', 'ji', 'qin', 'zhao', 'sun', 'ya', 'zhui', 'yuan', 'hu',
  0x10 => 'hang', 'xiao', 'cen', 'bi', 'bi', 'jian', 'yi', 'dong', 'shan', 'sheng', 'da', 'di', 'zhu', 'na', 'chi', 'gu',
  0x20 => 'li', 'qie', 'min', 'bao', 'tiao', 'si', 'fu', 'ce', 'ben', 'pei', 'da', 'zi', 'di', 'ling', 'ze', 'nu',
  0x30 => 'fu', 'gou', 'fan', 'jia', 'gan', 'fan', 'shi', 'mao', 'po', 'ti', 'jian', 'qiong', 'long', 'min', 'bian', 'luo',
  0x40 => 'gui', 'qu', 'chi', 'yin', 'yao', 'xian', 'bi', 'qiong', 'kuo', 'deng', 'xiao', 'jin', 'quan', 'sun', 'ru', 'fa',
  0x50 => 'kuang', 'zhu', 'tong', 'ji', 'da', 'hang', 'ce', 'zhong', 'kou', 'lai', 'bi', 'shai', 'dang', 'zheng', 'ce', 'fu',
  0x60 => 'yun', 'tu', 'pa', 'li', 'lang', 'ju', 'guan', 'jian', 'han', 'tong', 'xia', 'zhi', 'cheng', 'suan', 'shi', 'zhu',
  0x70 => 'zuo', 'xiao', 'shao', 'ting', 'ce', 'yan', 'gao', 'kuai', 'gan', 'chou', 'kuang', 'gang', 'yun', 'o', 'qian', 'xiao',
  0x80 => 'jian', 'pou', 'lai', 'zou', 'bi', 'bi', 'bi', 'ge', 'tai', 'guai', 'yu', 'jian', 'dao', 'gu', 'chi', 'zheng',
  0x90 => 'qing', 'sha', 'zhou', 'lu', 'bo', 'ji', 'lin', 'suan', 'jun', 'fu', 'zha', 'gu', 'kong', 'qian', 'qian', 'jun',
  0xA0 => 'chui', 'guan', 'yuan', 'ce', 'zu', 'bo', 'ze', 'qie', 'tuo', 'luo', 'dan', 'xiao', 'ruo', 'jian', 'xuan', 'bian',
  0xB0 => 'sun', 'xiang', 'xian', 'ping', 'zhen', 'xing', 'hu', 'yi', 'zhu', 'yue', 'chun', 'lu', 'wu', 'dong', 'shuo', 'ji',
  0xC0 => 'jie', 'huang', 'xing', 'mei', 'fan', 'chuan', 'zhuan', 'pian', 'feng', 'zhu', 'huang', 'qie', 'hou', 'qiu', 'miao', 'qian',
  0xD0 => 'gu', 'kui', 'shi', 'lou', 'yun', 'he', 'tang', 'yue', 'chou', 'gao', 'fei', 'ruo', 'zheng', 'gou', 'nie', 'qian',
  0xE0 => 'xiao', 'cuan', 'long', 'peng', 'du', 'li', 'bi', 'zhuo', 'chu', 'shai', 'chi', 'zhu', 'qiang', 'long', 'lan', 'jian',
  0xF0 => 'bu', 'li', 'hui', 'bi', 'di', 'cong', 'yan', 'peng', 'can', 'zhuan', 'pi', 'piao', 'dou', 'yu', 'mie', 'tuan',
];
